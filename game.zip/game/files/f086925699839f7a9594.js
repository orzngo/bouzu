(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.aez_bundle_main = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";
var LoadingScene_1 = require("./scenes/LoadingScene");
var MyInitialScene_1 = require("./scenes/MyInitialScene");
function main(param) {
    // ローディング画面をカスタマイズしない場合は消す
    g.game.loadingScene = new LoadingScene_1.LoadingScene();
    g.game.vars.isAtsumaru = false;
    if (typeof window !== 'undefined' && window.RPGAtsumaru) {
        g.game.vars.isAtsumaru = true;
    }
    g.game.pushScene(new MyInitialScene_1.MyInitialScene());
}
module.exports = main;

},{"./scenes/LoadingScene":3,"./scenes/MyInitialScene":5}],2:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var MainScene_1 = require("./MainScene");
var ResultScene_1 = require("./ResultScene");
var DescriptionScene = (function (_super) {
    __extends(DescriptionScene, _super);
    function DescriptionScene(remainingTime) {
        var _this = _super.call(this, { game: g.game, assetIds: ["title"] }) || this;
        _this.remainingTime = remainingTime;
        _this.frameCount = 0;
        _this.loaded.addOnce(function () {
            _this.initialize();
        });
        return _this;
    }
    DescriptionScene.prototype.initialize = function () {
        var _this = this;
        this.append(new g.FilledRect({ scene: this, width: g.game.width, height: g.game.height, cssColor: "white" }));
        var font = new g.DynamicFont({ game: g.game, fontFamily: g.FontFamily.Serif, size: 40 });
        var label = new g.Label({ scene: this, font: font, text: "スコアがランダムに決まります", fontSize: 40 });
        label.x = (g.game.width / 2) - label.width / 2;
        label.y = (g.game.height / 2) - label.height / 2;
        this.append(label);
        this.update.add(function () {
            _this.mainLoop();
        });
    };
    DescriptionScene.prototype.mainLoop = function () {
        this.frameCount++;
        if (this.frameCount > DescriptionScene.LENGTH_SECONDS * g.game.fps) {
            g.game.replaceScene(new MainScene_1.MainScene(this.remainingTime - DescriptionScene.LENGTH_SECONDS - ResultScene_1.ResultScene.LENGTH_SECONDS));
        }
    };
    DescriptionScene.LENGTH_SECONDS = 5;
    return DescriptionScene;
}(g.Scene));
exports.DescriptionScene = DescriptionScene;

},{"./MainScene":4,"./ResultScene":6}],3:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Loading中に出るシーン
 * 一番最初の読み込み以外ではこいつがでる
 */
var LoadingScene = (function (_super) {
    __extends(LoadingScene, _super);
    function LoadingScene() {
        var _this = _super.call(this, {
            game: g.game,
            explicitEnd: true
        }) || this;
        _this.isTargetReady = false;
        _this.frameCount = 0;
        _this.font = new g.DynamicFont({ game: g.game, fontFamily: g.FontFamily.Serif, size: 40 });
        _this.loaded.addOnce(function () {
            _this.initialize();
        });
        _this.targetReset.add(function () {
            _this.initialize();
        });
        _this.targetReady.add(function () {
            _this.finalize();
        });
        return _this;
    }
    LoadingScene.prototype.initialize = function () {
        var _this = this;
        this.append(new g.FilledRect({ scene: this, width: g.game.width, height: g.game.height, cssColor: "white" }));
        var icon = new g.FrameSprite({
            src: g.game.assets["loading"],
            width: 256,
            height: 256,
            srcWidth: 128,
            srcHeight: 128,
            scene: this,
            frames: [0, 1, 2],
            interval: 125
        });
        icon.x = (g.game.width / 2) - icon.width / 2;
        icon.y = (g.game.height / 2) - icon.height / 2;
        this.append(icon);
        icon.start();
        this.label = new g.Label({ scene: this, font: this.font, text: "LOADING", fontSize: 256 / 7 });
        this.label.x = icon.x;
        this.label.y = icon.y + icon.height;
        this.append(this.label);
        this.fadeOutRect = new g.FilledRect({
            scene: this,
            width: g.game.width,
            height: g.game.height,
            cssColor: "rgba(0,0,0,0)"
        });
        this.append(this.fadeOutRect);
        this.update.add(function () {
            _this.mainLoop();
        });
    };
    LoadingScene.prototype.mainLoop = function () {
        if (!this.isTargetReady) {
            this.updateLabel();
            return;
        }
        // FIXME: 終了演出を挟もうとするとエラー出る
        /*
        this.frameCount++;
        this.fadeOutRect.cssColor = `rgba(0,0,0,${this.frameCount / 100})`;

        if (this.frameCount > 3 * g.game.fps) {
            this.end();
        }
        */
    };
    LoadingScene.prototype.updateLabel = function () {
        this.label.text = "LOADING " + this.getTargetWaitingAssetsCount();
        this.label.modified();
    };
    LoadingScene.prototype.finalize = function () {
        this.end();
        // FIXME: なんか終了演出を挟むと次のsceneがno sceneとかいわれる
        //this.isTargetReady = true;
    };
    return LoadingScene;
}(g.LoadingScene));
exports.LoadingScene = LoadingScene;

},{}],4:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ResultScene_1 = require("./ResultScene");
var MainScene = (function (_super) {
    __extends(MainScene, _super);
    function MainScene(remainingTime) {
        var _this = _super.call(this, { game: g.game, assetIds: ["title"] }) || this;
        _this.remainingTime = remainingTime;
        _this.frameCount = 0;
        _this.loaded.addOnce(function () {
            _this.initialize();
        });
        return _this;
    }
    MainScene.prototype.initialize = function () {
        var _this = this;
        this.append(new g.FilledRect({ scene: this, width: g.game.width, height: g.game.height, cssColor: "white" }));
        var font = new g.DynamicFont({ game: g.game, fontFamily: g.FontFamily.Serif, size: 40 });
        var label = new g.Label({ scene: this, font: font, text: "MAIN GAMEN", fontSize: 64 });
        label.x = (g.game.width / 2) - label.width / 2;
        this.append(label);
        this.titleImage = new g.Sprite({ scene: this, src: this.assets["title"] });
        this.titleImage.x = (g.game.width / 2) - this.titleImage.width / 2;
        this.titleImage.y = (g.game.height / 2) - this.titleImage.height / 2;
        this.append(this.titleImage);
        this.scoreLabel = new g.Label({ scene: this, font: font, text: "RANDOM SCORE: 0", fontSize: 16 });
        this.scoreLabel.y = this.game.height - 16;
        this.append(this.scoreLabel);
        this.timerLabel = new g.Label({ scene: this, font: font, text: "TIME:", fontSize: 16 });
        this.append(this.timerLabel);
        this.update.add(function () {
            _this.mainLoop();
        });
        this.isRunning = true;
    };
    MainScene.prototype.mainLoop = function () {
        this.frameCount++;
        this.timerLabel.text = "TIME: " + this.getRemainingTime();
        this.timerLabel.invalidate();
        if (this.frameCount % 10 === 0 && this.isRunning) {
            this.game.vars.gameState.score = this.game.random.get(0, 100000);
            this.scoreLabel.text = "RANDOM SCORE: " + this.game.vars.gameState.score;
            this.scoreLabel.invalidate();
        }
        if (this.isRunning) {
            this.titleImage.angle = 360 - this.frameCount % 360;
            this.titleImage.modified();
        }
        // 終了演出のため、残り時間より少し早めにゲームを止める
        if (this.getRemainingTime() === 5 && this.isRunning) {
            this.isRunning = false;
        }
        if (this.getRemainingTime() === 0) {
            this.finalize();
        }
        if (this.game.vars.isAtsumaru && this.getRemainingTime() === 0 && this.isRunning) {
            this.isRunning = false;
            window.RPGAtsumaru.experimental.scoreboards.setRecord(1, this.game.vars.gameState.score);
            this.setTimeout(function () {
                window.RPGAtsumaru.experimental.scoreboards.display(1);
            }, 3000);
        }
    };
    MainScene.prototype.finalize = function () {
        g.game.replaceScene(new ResultScene_1.ResultScene());
    };
    MainScene.prototype.getRemainingTime = function () {
        return this.remainingTime - Math.floor(this.frameCount / this.game.fps);
    };
    return MainScene;
}(g.Scene));
exports.MainScene = MainScene;

},{"./ResultScene":6}],5:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 実験放送関連のイベントを受け取ってなんかする
 * アツマール上で動いている場合は何もせずシーン遷移する
 * 実験放送でもアツマールでもない環境（ローカルなど）ではちょっと待ってから勝手にシーン遷移する
 */
var TitleScene_1 = require("./TitleScene");
var MyInitialScene = (function (_super) {
    __extends(MyInitialScene, _super);
    function MyInitialScene() {
        var _this = _super.call(this, { game: g.game }) || this;
        _this.frameCount = 0;
        _this.isInitializeStarted = false;
        if (g.game.vars.isAtsumaru) {
            _this.loaded.add(function () {
                _this.initialize();
            });
        }
        else {
            _this.message.add(function (e) {
                if (e.data && e.data.type === "start") {
                    if (e.data.parameters) {
                        g.game.vars.parameters = e.data.parameters;
                    }
                    _this.initialize();
                }
            });
        }
        // 実験放送でもアツマールでもない時はstartがこないため、ループでちょっと待って開始する
        _this.update.add(function () {
            _this.mainLoop();
        });
        return _this;
    }
    MyInitialScene.prototype.initialize = function () {
        if (this.isInitializeStarted) {
            return;
        }
        this.isInitializeStarted = true;
        g.game.vars.totalTimeLimit = 60;
        if (g.game.vars.parameters && g.game.vars.parameters.totalTimeLimit && g.game.vars.parameters.totalTimeLimit > 0) {
            g.game.vars.totalTimeLimit = g.game.vars.parameters.TotalTimeLimit;
        }
        g.game.vars.gameState = {
            score: 0
        };
        g.game.replaceScene(new TitleScene_1.TitleScene(g.game.vars.totalTimeLimit));
    };
    // アツマールでもなく、実験放送でもない時、ちょっと待ってから自動で初期化開始するためのループ
    MyInitialScene.prototype.mainLoop = function () {
        this.frameCount++;
        if (this.frameCount > 2 * g.game.fps) {
            this.initialize();
        }
    };
    return MyInitialScene;
}(g.Scene));
exports.MyInitialScene = MyInitialScene;

},{"./TitleScene":7}],6:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ResultScene = (function (_super) {
    __extends(ResultScene, _super);
    function ResultScene(remainingTime) {
        if (remainingTime === void 0) { remainingTime = ResultScene.LENGTH_SECONDS; }
        var _this = _super.call(this, { game: g.game, assetIds: ["title"] }) || this;
        _this.remainingTime = remainingTime;
        _this.frameCount = 0;
        _this.isRunning = false;
        _this.loaded.addOnce(function () {
            _this.initialize();
        });
        return _this;
    }
    ResultScene.prototype.initialize = function () {
        var _this = this;
        this.append(new g.FilledRect({ scene: this, width: g.game.width, height: g.game.height, cssColor: "white" }));
        var font = new g.DynamicFont({ game: g.game, fontFamily: g.FontFamily.Serif, size: 40 });
        var label = new g.Label({ scene: this, font: font, text: g.game.vars.gameState.score + " pt", fontSize: 40 });
        label.x = (g.game.width / 2) - label.width / 2;
        label.y = (g.game.height / 2) - label.height / 2;
        this.append(label);
        this.update.add(function () {
            _this.mainLoop();
        });
        this.isRunning = true;
    };
    ResultScene.prototype.mainLoop = function () {
        this.frameCount++;
        if (this.game.vars.isAtsumaru && this.getRemainingTime() === 0 && this.isRunning) {
            this.isRunning = false;
            window.RPGAtsumaru.experimental.scoreboards.setRecord(1, this.game.vars.gameState.score);
            this.setTimeout(function () {
                window.RPGAtsumaru.experimental.scoreboards.display(1);
            }, 3000);
        }
    };
    ResultScene.prototype.getRemainingTime = function () {
        return this.remainingTime - Math.floor(this.frameCount / this.game.fps);
    };
    ResultScene.LENGTH_SECONDS = 5;
    return ResultScene;
}(g.Scene));
exports.ResultScene = ResultScene;

},{}],7:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var DescriptionScene_1 = require("./DescriptionScene");
/**
 * 最初に出すシーン
 */
var TitleScene = (function (_super) {
    __extends(TitleScene, _super);
    function TitleScene(remainingTime) {
        var _this = _super.call(this, { game: g.game, assetIds: ["title"] }) || this;
        _this.remainingTime = remainingTime;
        _this.frameCount = 0;
        _this.loaded.add(function () {
            _this.initialize();
        });
        return _this;
    }
    TitleScene.prototype.initialize = function () {
        var _this = this;
        this.append(new g.FilledRect({ scene: this, width: g.game.width, height: g.game.height, cssColor: "white" }));
        var font = new g.DynamicFont({ game: g.game, fontFamily: g.FontFamily.Serif, size: 40 });
        var label = new g.Label({ scene: this, font: font, text: "TITLE GAMEN", fontSize: 64 });
        label.x = (g.game.width / 2) - label.width / 2;
        this.append(label);
        var timeLabel = new g.Label({
            scene: this,
            font: font,
            text: "totalTimeLimit: " + this.remainingTime,
            fontSize: 64
        });
        timeLabel.x = (g.game.width / 2) - (timeLabel.width / 2);
        timeLabel.y = g.game.height - timeLabel.height;
        this.append(timeLabel);
        this.titleImage = new g.Sprite({ scene: this, src: this.assets["title"] });
        this.titleImage.x = (g.game.width / 2) - this.titleImage.width / 2;
        this.titleImage.y = (g.game.height / 2) - this.titleImage.height / 2;
        this.append(this.titleImage);
        this.update.add(function () {
            _this.mainLoop();
        });
    };
    TitleScene.prototype.mainLoop = function () {
        this.frameCount++;
        this.titleImage.angle = this.frameCount % 360;
        this.titleImage.modified();
        if (this.frameCount > TitleScene.LENGTH_SECONDS * g.game.fps) {
            g.game.replaceScene(new DescriptionScene_1.DescriptionScene(this.remainingTime - TitleScene.LENGTH_SECONDS));
        }
    };
    TitleScene.LENGTH_SECONDS = 5;
    return TitleScene;
}(g.Scene));
exports.TitleScene = TitleScene;

},{"./DescriptionScene":2}]},{},[1])(1)
});
